#include<stdio.h>

int main(){
    FILE *ptr;
    // ptr = fopen("sample2.txt", "r"); //--> for reading the file
    //ptr = fopen("sample2.txt", "w"); //--> for writing to a file
    return 0;
}